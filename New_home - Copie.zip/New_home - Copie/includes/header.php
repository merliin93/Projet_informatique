
<header>
<link href="./css/style.css" rel="stylesheet">

<nav id="mynav" class="navbar navbar-expand-lg wrapper navbar-dark sticky-top" style=" background-color:pink;
    color:white;">
     <div>
    <img src="../img/logo_mas_dagenais.png" alt="picture here" width='70px' height='60px'>
    <a href="index.php"></a>
        </div>
  <div class="container-fluid">
    <a class="navbar-brand fw-bold" href="index.php">Accueil</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active b" href="#presEhpad">Présentation de l'EHPAD</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active bold" href="./votre_sejour.php">votre séjour</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active bold" href="./offre_emploi.php">offre d'emploi</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active bold" href="./contact.php">contact</a>
        </li>
       
      </ul>
    </div>
  </div>
</nav>
     

    </header>
    <!--Main Navigation-->
   
    