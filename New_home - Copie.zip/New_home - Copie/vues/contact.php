<?php 
require_once('../includes/header.php')


?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    
   <!-- Wrapper container -->
<div class="container py-4 col-4">

<!-- Bootstrap 5 starter form -->
<form id="contactForm">

  <!-- Name input -->
  <div class="mb-3">
    <label class="form-label" for="name">Nom</label>
    <input class="form-control" id="name" type="text" placeholder="Nom" data-sb-validations="required" />
  </div>

  <!-- Email address input -->
  <div class="mb-3">
    <label class="form-label" for="emailAddress">Adresse email</label>
    <input class="form-control" id="emailAddress" type="email" placeholder="adresse mail" data-sb-validations="required, email" />
  </div>

  <!-- Message input -->
  <div class="mb-3">
    <label class="form-label" for="message">Message</label>
    <textarea class="form-control" id="message" type="text" placeholder="Message" style="height: 10rem;" data-sb-validations="required"></textarea>
  </div>

  

  <!-- Form submit button -->
  <div class="d-grid">
    <button class="form-submit-button" type="submit">Envoyer</button>
  </div>

</form>

</div>
    <!--Grid column-->

    <!--Grid column-->
    <div class="col-lg-7 col-md-12">

        <!--Grid row-->
        <div class="row text-center">

            <!--Grid column-->
            <div class="col-lg-4 col-md-12 mb-3">

                <p><i class="fa fa-map fa-1x mr-2 grey-text"></i>16 Chem. de venteuilh, 47430 Le Mas-d'Agenais</p>

            </div>               
            
            <!--Grid column-->
            <div class="col-lg-4 col-md-6 mb-3">

                <p><i class="fa fa-phone fa-1x mr-2 grey-text"></i>tel: 05 53 89 57 57</p>

            </div>
            <!--Grid column-->

        </div>
        <!--Grid row-->

        <iframe width="100%" height="300px" frameborder="0" allowfullscreen src="https://framacarte.org/fr/map/carte-sans-nom_125526?scaleControl=false&miniMap=false&scrollWheelZoom=false&zoomControl=true&allowEdit=false&moreControl=false&searchControl=null&tilelayersControl=null&embedControl=null&datalayersControl=false&onLoadPanel=undefined&captionBar=false"></iframe>

    </div>
    <!--Grid column-->

    <?php include("../includes/footer.php") ?>


    <style>
    .form-submit-button {
background: #FFB6C1;
color: white;
box-shadow:5px 10px;
border-color: #FFB6C1;
height: 50px;
width: 100px;
font: bold 15px arial, sans-serif;
text-shadow:none;
margin-left: auto;
margin-right: auto;
border-radius:25%;
}
  </style>
    
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
