<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
    
    <link href="./css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    
    <title>Accueil</title>
</head>
<body>
<?php   

include("../includes/header.php");
?>
<h1 style="text-align:center; margin:20px">Votre Séjour</h1>
<div class="container">
        <div style="border:1px solid black;margin:50px;padding:100px;">
            <h2>LES DÉPÔTS D'ARGENT ET DE VALEURS</h2>
            Toute personne admise dans l’Établissement est invitée à déposer lors de son entrée, les 
            valeurs en sa possession (somme d’argent, chèques, bijoux, appareil informatique, 
            téléphone…).
            Les dépôts effectués auprès du régisseur de l’Établissement sont remis au comptable public 
            (Trésorerie de Marmande). Un reçu est donné au déposant. 
            Si vous décidez de conserver vos biens, la responsabilité de l’EHPAD ne pourra être engagée 
            en cas de perte ou de vol.
        </div>


        <div style="border:1px solid black;margin:50px;padding:100px;">
            <h2>VOTRE ENVIRONNEMENT </h2>
            <h3>Les repas</h3>
            La production des repas est faite sur place par le service de restauration. Ils sont pris en 
            chambre ou en en salle à manger.
            Les menus sont élaborés par une diététicienne qui garantit la bonne qualité nutritionnelle et 
            le respect de l'équilibre alimentaire. Ces repas sont étudiés en Commission de Restauration. 
            Si vous le désirez, votre entourage peut partager un repas avec vous. Pour cela, il vous faudra 
            prévenir le jour précédent et vous acquitter du paiement à l’accueil.
            Les repas sont servis à horaires réguliers. 
            - 07H30 : Petit déjeuner
            - 12H15 : Repas 
            - 15H30 : Goûter
            - 18H30 : Dîner 
            <h3>Le linge </h3>
            Vous devez fournir un trousseau marqué à votre nom (par étiquettes cousues) avant votre 
            arrivée (liste donnée lors de la réservation). L’entretien du linge est assuré par l’Établissement. 
            Le linge trop délicat est déconseillé, car non prévu par nos processus de lavage et de séchage 
            industriel. L'entretien peut être réalisé par la famille.
        </div>

        <div style="border:1px solid black;margin:50px;padding:100px;">
            <h2>LES SERVICES ET PRESTATIONS PROPOSÉS </h2>
            <h4>La télévision</h4>
            Chaque chambre est équipée d’un téléviseur.
            <h4>Le téléphone</h4>
            Il est possible d’ouvrir une ligne directe externe auprès d’Orange.
            <h4>Le courrier</h4>
            Il est distribué tous les jours par le personnel du service. Vos envois peuvent être déposés 
            affranchis à l’accueil.
            <h4>Le journal</h4>
            Le journal "Sud-ouest" est mis tous les jours à votre disposition à l'accueil de l'établissement.
            <h4>Prestation coiffure et esthétique</h4>
            Un salon de coiffure est à votre disposition dans l’établissement.
            Des professionnels extérieurs interviennent régulièrement. Cette prestation est à la charge des 
            résidents.
            <h4>Les soins de pédicure</h4>
            Ils sont à votre charge et peuvent être effectués par le pédicure de votre choix.
        </div>
        <div style="border:1px solid black;margin:50px;padding:100px;">
            <h2>LE RESPECT DE CHAQUE CONFESSION</h2>
            Des ministres du culte de votre choix peuvent vous rendre visite si vous en exprimez le désir. 
            La liste et les coordonnées sont à demander au poste de soins. Un office catholique est 
            organisé une fois par mois le mercredi.

        </div>


</div>

<!--Main layout-->
<?php include("../includes/footer.php") ?>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>

</body>
</html>