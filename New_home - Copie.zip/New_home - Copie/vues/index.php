<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
    
    <link href="./css/style.css" rel="stylesheet">
    <link href="./css/css_stroke.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    
    <title>Accueil</title>
</head>
<body>
<?php   

include("../includes/header.php");
?>

        
            
        


            <div id="carouselExampleCaptions" class="carousel slide w-100"  data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="../img/ehpadvueciel.jpg" class="d-block w-100" alt="jardin">
      <div class="carousel-caption d-none d-md-block">
        <h5>Vue aérienne de l'EHPAD </h5>
        <p></p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="../img/cuisineEHPAD.jpg" class="d-block w-100" alt="cuisine">
      <div class="carousel-caption d-none d-md-block">
        <h5>La cuisine</h5>
        <p></p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="../img/salleamangerEHPAD.jpg" class="d-block w-100" alt="salle a manger">
      <div class="carousel-caption d-none d-md-block">
        <h5>La salle à manger</h5>
        <p></p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">précédent</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">suivant</span>
  </button>
</div>




                <h1 id="presEhpad" class="grey-text">Presentation de l'EHPAD :</h1>
                    <p>L’EHPAD du Mas d’agenais est un établissement médico-social public autonome de 61 lits. Il 
                    fait partie de la direction commune avec le Centre hospitalier de Casteljaloux dirigée par Mme 
                    Catherine DARIES. Le conseil d’administration est présidé par Monsieur Claude LAGARDE, 
                    maire du Mas d’agenais.
                    Il accueille des personnes âgées dépendantes de 60 ans et plus (sauf dérogation).

                    

                    <h2><b>Situation géographique </b></h2><br>
                    Situé à proximité immédiate de la Maison de santé Simone Veil, l’EHPAD est situé au lieu-dit 
                    Venteuilh, au Mas d’agenais, à 16 km de Casteljaloux et 13 km de Marmande. 

                    
        <iframe width="100%" height="300px" frameborder="0" allowfullscreen src="https://framacarte.org/fr/map/carte-sans-nom_125526?scaleControl=false&miniMap=false&scrollWheelZoom=false&zoomControl=true&allowEdit=false&moreControl=false&searchControl=null&tilelayersControl=null&embedControl=null&datalayersControl=false&onLoadPanel=undefined&captionBar=false"></iframe>

                    <h2><b>Les horaires d'ouverture</b></h2><br>

                




                    Le service d'Hébergement pour Personnes Âgées Dépendantes est ouvert tous les jours. 
                    Des horaires de visite vous sont proposés de 12h à 20h. Cependant, il est possible de venir en 
                    dehors de ces horaires en demandant l'accord préalable aux infirmiers du service.
                    L’accueil est ouvert du lundi au vendredi de 9h à 16h30.</p>

                    <h2>Les professionnels qui vous accompagnent :</h2>
                    <b>Le médecin coordonnateur</b></br>. La coordination des intervenants médicaux est organisée par 
le Docteur François LIBES, médecin coordonnateur. Les familles ou les proches peuvent être 
reçus en prenant RDV auprès du bureau des admissions.</br>
<b>L’infirmière coordonnatrice</b>,</br> Mme Sandrine LAGUE BONNET, gère les équipes de l'EHPAD 
en collaboration avec le médecin coordonnateur et se tient à votre disposition pour toute 
information ou réclamation. 
</br><b> La psychologue </b>, Mme Anna TARANTO, réalise des évaluations psychologiques et 
neuropsychologiques et peut vous accompagner vous et votre entourage si vous le souhaitez. 
</br> </br><b> Les infirmières </b> dispensent les soins nécessaires à votre prise en charge dans le respect des 
règles de leur pratique professionnelle. Elles participent également à l'accompagnement du 
résident. 
</br></br> <b> Les aides-soignantes </b> vous accompagnent dans la réalisation des actes de la vie quotidienne 
et contribuent à son confort. 
</br></br><b> Les agents des services hospitaliers </b> assurent l'entretien de votre chambre et du service 
et participent à l'accompagnement des résidents en facilitant leurs déplacements. 
</br></br><b>Les animateurs </b> accompagnent les résidents en vous proposant des animations et des 
activités collectives plusieurs fois par semaine. Le planning est affiché chaque semaine.</br>



<h2>Le suivi médical : </h2>
Les résidents conservent le choix de leur médecin traitant qui devra être désigné par écrit. 
Les infirmières dispensent les soins et actes prescrits par votre médecin.
Le personnel médical et toute l’équipe restent à votre écoute pour vous offrir un 
accompagnement de qualité, adapté à vos besoins, 24 heures sur 24.

<h2>Les locaux :</h2>
L’EHPAD du Mas d’agenais dispose de chambres simples et de chambres doubles réparties sur 
deux étages et un rez-de-chaussée. Les chambres sont équipées de placards de rangement et 
d’un petit balcon ou d’une terrasse.
Un parc arboré permet des promenades agréables et ombragées
                


        

<!--Main layout-->
<?php include("../includes/footer.php") ?>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>

</body>
</html>