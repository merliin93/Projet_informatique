<?php 
session_start();
if(isset($_POST['valider'])){
    if(!empty($_POST["nom"]) && !empty($_POST['password'])){
        $nom_par_defaut = "admin";
        $mdp_par_defaut = "password";

        $pseudo_saisi =htmlspecialchars($_POST['nom']);
        $mdp_saisi =htmlspecialchars($_POST['password']);

        if($pseudo_saisi == $nom_par_defaut && $mdp_saisi == $mdp_par_defaut){
            $_SESSION['password']= $mdp_saisi;
            header('location : administrateur.php');
        }else{
            echo"nom ou mot de passe incorrect";
        }

        } else {
            echo"veuillez completer tous les champs";
    }
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>espace de connexion admin</title>
</head>
<body>
  <h1 style="text-align:center;margin-top:100px">Connexion à l'espace admin </h1>
  <img src="../img/spy.png" class="w-25">
      <div class="container py-4 col-4" style="margin-top:-400px">
        <form method="POST" action="">
          <!-- Email input -->
          <div class="form-outline mb-4">
          <label class="form-label" for="nom" value="nom">Nom</label>
            <input type="text" name="nom" id="nom" class="form-control" autocomplete="off" />
           
          </div>

          <!-- Password input -->
          <div class="form-outline mb-4">
          <label class="form-label" for="mdp" value="mdp" >Mot de passe</label>
            <input type="password"name="password" id="password" class="form-control" />
           
          </div>


            <div class="col">
              <!-- Simple link -->
              <a href="#!">mot de passe oublié ?</a>
            </div>
          

          <!-- Submit button -->
          <button type="button" name="valider" class="btn btn-primary btn-block mb-4">se connecter</button>

          <!-- Register buttons -->

        </form>
      </div>      
</body>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>